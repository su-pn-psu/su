--
-- Database: `su_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin', 2, 1472824473),
('theCreator', 1, 1473217450);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/basicfilemanager/*', 2, NULL, NULL, NULL, 1473168548, 1473168548),
('/borrow-material/*', 2, NULL, NULL, NULL, 1473387077, 1473387077),
('/menu/*', 2, NULL, NULL, NULL, 1473094894, 1473094894),
('/site/*', 2, NULL, NULL, NULL, 1473092529, 1473092529),
('/site/index', 2, NULL, NULL, NULL, 1473092658, 1473092658),
('/user/*', 2, NULL, NULL, NULL, 1473166817, 1473166817),
('admin', 1, 'Administrator of this application', NULL, NULL, 1472803072, 1472803072),
('employee', 1, 'Employee of this site/company who has lower rights than admin', NULL, NULL, 1472803072, 1472803072),
('managerMenus', 2, NULL, NULL, NULL, 1473094862, 1473094862),
('manageUsers', 2, 'Allows admin+ roles to manage users', NULL, NULL, 1472803072, 1472803072),
('member', 1, 'Authenticated user, equal to "@"', NULL, NULL, 1472803072, 1472803072),
('premium', 1, 'Premium users. Authenticated users with extra powers', NULL, NULL, 1472803072, 1472803072),
('theCreator', 1, 'You!', NULL, NULL, 1472803072, 1472803072),
('usePremiumContent', 2, 'Allows premium+ roles to use premium content', NULL, NULL, 1472803072, 1472803072);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('admin', '/basicfilemanager/*'),
('admin', '/borrow-material/*'),
('admin', '/site/index'),
('admin', '/user/*'),
('admin', 'managerMenus'),
('admin', 'manageUsers'),
('employee', 'premium'),
('managerMenus', '/menu/*'),
('premium', 'member'),
('premium', 'usePremiumContent'),
('theCreator', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_rule`
--

INSERT INTO `auth_rule` (`name`, `data`, `created_at`, `updated_at`) VALUES
('isAuthor', 'O:28:"common\\rbac\\rules\\AuthorRule":3:{s:4:"name";s:8:"isAuthor";s:9:"createdAt";i:1472803071;s:9:"updatedAt";i:1472803071;}', 1472803071, 1472803071);

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `id` varchar(30) NOT NULL COMMENT 'รหัสครุภัณฑ์',
  `title` varchar(255) NOT NULL COMMENT 'ชื่อ',
  `brand` varchar(100) DEFAULT NULL COMMENT 'ยี่ห้อ',
  `status` int(1) DEFAULT NULL COMMENT 'สถานะ',
  `material_type_id` int(11) DEFAULT NULL COMMENT 'ประเภท',
  `bought_at` date DEFAULT NULL COMMENT 'วันที่ซื้อ',
  `warrant_at` date DEFAULT NULL COMMENT 'วันที่หมดประกัน',
  `created_at` int(11) DEFAULT NULL COMMENT 'สร้างเมื่อ',
  `created_by` int(11) DEFAULT NULL COMMENT 'สร้างโดย',
  `updated_at` int(11) DEFAULT NULL COMMENT 'ปรับปรุงเมื่อ',
  `updated_by` int(11) DEFAULT NULL COMMENT 'แก้ไขโดย'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `material_type`
--

CREATE TABLE `material_type` (
  `id` int(11) NOT NULL COMMENT 'รหัสประเภท',
  `title` varchar(255) DEFAULT NULL COMMENT 'ชื่อประเภท'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL COMMENT 'รหัสเมนู',
  `menu_category_id` int(11) DEFAULT NULL COMMENT 'รหัสหมวดเมนู',
  `parent_id` int(11) DEFAULT NULL COMMENT 'ภายใต้เมนู',
  `title` varchar(200) NOT NULL COMMENT 'ชื่อเมนู',
  `router` varchar(250) NOT NULL COMMENT 'ลิงค์',
  `parameter` varchar(250) DEFAULT NULL COMMENT 'พารามิเตอร์',
  `icon` varchar(30) DEFAULT NULL COMMENT 'ไอคอน',
  `status` enum('2','1','0') DEFAULT '0' COMMENT 'สถานะ',
  `item_name` varchar(64) DEFAULT NULL COMMENT 'บทบาท',
  `target` varchar(30) DEFAULT NULL COMMENT 'เป้าหมาย',
  `protocol` varchar(20) DEFAULT NULL COMMENT 'โปรโตคอล',
  `home` enum('1','0') DEFAULT '0' COMMENT 'หน้าแรก',
  `sort` int(3) DEFAULT NULL COMMENT 'เรียง',
  `language` varchar(7) DEFAULT '*' COMMENT 'ภาษา',
  `params` mediumtext COMMENT 'ลักษณะพิเศษ',
  `assoc` varchar(12) DEFAULT NULL COMMENT 'ชุดเมนู',
  `created_at` int(11) DEFAULT NULL COMMENT 'สร้างเมื่อ',
  `created_by` int(11) DEFAULT NULL COMMENT 'สร้างโดย',
  `name` varchar(128) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `route` varchar(256) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ระบบเมนู';

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `menu_category_id`, `parent_id`, `title`, `router`, `parameter`, `icon`, `status`, `item_name`, `target`, `protocol`, `home`, `sort`, `language`, `params`, `assoc`, `created_at`, `created_by`, `name`, `parent`, `route`, `order`, `data`) VALUES
(33, NULL, NULL, '', '', NULL, NULL, '0', NULL, NULL, NULL, '0', NULL, '*', NULL, NULL, NULL, NULL, 'หน้าแรก', NULL, '/site/index', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu_auth`
--

CREATE TABLE `menu_auth` (
  `menu_id` int(11) NOT NULL,
  `item_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menu_category`
--

CREATE TABLE `menu_category` (
  `id` int(11) NOT NULL COMMENT 'รหัสหมวดเมนู',
  `title` varchar(50) NOT NULL COMMENT 'ชื่อหมวดเมนู',
  `discription` varchar(255) DEFAULT NULL COMMENT 'คำอธิบาย',
  `status` enum('1','0') DEFAULT NULL COMMENT 'สถานะ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='หมวดเมนู';

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1472790233),
('m130524_201442_init', 1473212850),
('m141022_115823_create_user_table', 1472790235),
('m141022_115912_create_rbac_tables', 1472790235),
('m141022_115922_create_session_table', 1472790235),
('m160425_081413_create_user_profile_table', 1473212885);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL COMMENT 'เรื่อง',
  `status` int(1) DEFAULT NULL COMMENT 'สถานะ',
  `detail` varchar(255) DEFAULT NULL COMMENT 'รายละเอียด',
  `router` varchar(255) DEFAULT NULL COMMENT 'เส้นทาง',
  `sented_at` int(11) DEFAULT NULL COMMENT 'ส่งเมื่อ',
  `sented_by` int(11) NOT NULL COMMENT 'ส่งโดย',
  `received_at` int(11) DEFAULT NULL COMMENT 'รับเมื่อ',
  `received_by` int(11) NOT NULL COMMENT 'อ่านโดย'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `user_id` int(11) NOT NULL COMMENT 'User Id',
  `status` int(1) NOT NULL COMMENT 'Status',
  `position_id` int(11) NOT NULL COMMENT 'Position',
  `title_id` int(11) NOT NULL COMMENT 'Title',
  `phd` int(1) NOT NULL DEFAULT '0' COMMENT 'Ph.D',
  `firstname_th` varchar(100) NOT NULL COMMENT 'First name TH',
  `lastname_th` varchar(100) NOT NULL COMMENT 'Last name TH',
  `firstname_en` varchar(100) NOT NULL COMMENT 'First name EN',
  `lastname_en` varchar(100) NOT NULL COMMENT 'Last name EN',
  `created_at` int(11) NOT NULL COMMENT 'Created at',
  `updated_at` int(11) NOT NULL COMMENT 'Updated at',
  `created_by` int(11) NOT NULL COMMENT 'Created by',
  `updated_by` int(11) NOT NULL COMMENT 'Updated by'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `id` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `expire` int(11) NOT NULL,
  `data` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `expire`, `data`) VALUES
('3j4qovqbrum3o0h79nqbh010q3', 1473879199, 0x5f5f666c6173687c613a303a7b7d),
('ion9ai5d9qf2mcchmcsquqo6l5', 1473260755, 0x5f5f666c6173687c613a303a7b7d),
('to5tfc9ef8d8eibikeiehetqc3', 1473100462, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a31323a222f73752f6261636b656e642f223b5f5f69647c693a313b);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'UWU4pJF3teH4kvNJeP6RE2olINBduTWR', '$2y$13$MkHJJFqYy2lwqGDnYq4RuuQR8DcYt7JJgoNgn7LCPkreLYMVFUuKe', NULL, 'admin@localhost.local', 10, 1473214315, 1473214315);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `avatar_offset` varchar(255) NOT NULL,
  `avatar_cropped` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `cover_offset` varchar(255) NOT NULL,
  `cover_cropped` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`user_id`, `firstname`, `lastname`, `avatar_offset`, `avatar_cropped`, `avatar`, `cover_offset`, `cover_cropped`, `cover`, `bio`, `data`) VALUES
(1, 'อาฮาหมัด', 'เจ๊ะดือราแม', '12.89-31.5-56.89-56.25', '32457cf77e4b1b3a_57cf77e4b03c9.jpg', '57cf77e4b03c9.jpg', '0-13.93-100-40.59', '35557cf789455e01_57cf789453308.jpg', '57cf789453308.jpg', '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material_type`
--
ALTER TABLE `material_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_cate_id` (`menu_category_id`) USING BTREE,
  ADD KEY `menu_parent` (`parent_id`);

--
-- Indexes for table `menu_auth`
--
ALTER TABLE `menu_auth`
  ADD PRIMARY KEY (`menu_id`,`item_name`);

--
-- Indexes for table `menu_category`
--
ALTER TABLE `menu_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_cate_id` (`id`,`title`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_ibfk_1` (`sented_at`),
  ADD KEY `notification_ibfk_2` (`received_at`),
  ADD KEY `sented_by` (`sented_by`),
  ADD KEY `received_by` (`received_by`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD UNIQUE KEY `uid` (`user_id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `material_type`
--
ALTER TABLE `material_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสประเภท';
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสเมนู', AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `menu_category`
--
ALTER TABLE `menu_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสหมวดเมนู';
--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`menu_category_id`) REFERENCES `menu_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `menu_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `menu` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `menu_auth`
--
ALTER TABLE `menu_auth`
  ADD CONSTRAINT `menu_auth_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
